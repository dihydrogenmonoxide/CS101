package boids;

import java.awt.Panel;

public abstract class BoidRuleView extends Panel {
}
